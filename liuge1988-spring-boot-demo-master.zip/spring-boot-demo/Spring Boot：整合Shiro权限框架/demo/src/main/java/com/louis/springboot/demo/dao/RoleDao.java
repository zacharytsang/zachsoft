package com.louis.springboot.demo.dao;

import com.louis.springboot.demo.model.Role;

public interface RoleDao extends BaseDao<Role, Long> {

}